import { Routes, Route } from "react-router-dom"
import HomePage from "./pages/HomePage"
import PredictionPage from "./pages/PredictionPage"

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/prediction" element={<PredictionPage />} />
    </Routes>
  )
}

export default App