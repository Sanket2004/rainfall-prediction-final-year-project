## Data generation
`/data/generate_data.py`

## Model training
`prediction.py`

## Model evaluation
`check_model.py`

## Model deployment
`/model/rainfall_model.pkl`